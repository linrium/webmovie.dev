<?php $__env->startSection('content'); ?>
<div id="newEpisodes" class="main__citem animated fadeInDown">
  <div class="row main__header">
    <div class="col-md-9 col-sm-7 col-xs-5">
      <h3>All Years</h3>
    </div>
  </div>

  <div class="row main__citem-content">
    <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <div class="col-lg-2 col-md-3 col-sm-4 col-xs-6" >
      <div class="main__citem-item">
        <a href="<?php echo route('yearpage.show', $year['id']); ?>">
          <div class="main__citem-des">
            <h2><?php echo e($year['name'] == 0 ? '???' : $year['name']); ?></h2>
          </div>
        </a>
        
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  </div>
</div>

<script>
  window.document.title = "Webmovie - Trang xem anime online";
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>