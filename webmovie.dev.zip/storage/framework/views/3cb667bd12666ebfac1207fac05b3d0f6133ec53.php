<?php $__env->startSection('content'); ?>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
    
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Genres manager</h1>
            <?php echo $__env->make('admin.component.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div><!--/.row-->
    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a class="btn btn-success" href="<?php echo route('genre.create'); ?>">Create Genre</a>
                </div>
                <div class="panel-body">
                    <h3><?php echo e($data->total()); ?> genres</h3>
                    <table class="table table-hover">
                        <thead>
                            <th>#</th>
                            <th>Genre</th>
                            <th>Edit</th>
                            <th>View</th>
                            <th>Delete</th>
                        </thead>
                        <tbody>
                            <?php $stt = 0; ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <?php $stt = $stt + 1; ?>
                                <tr>
                                    <th><?php echo $stt; ?></th>
                                    <td><?php echo $item['name']; ?></td>
                                    <td>
                                        <a class="btn btn-default" href="<?php echo URL::route('genre.edit', $item['id']); ?>">Edit</a>
                                    </td>
                                    <td>
                                        <a class="btn btn-default" href="<?php echo URL::route('genre.show', $item['id']); ?>">View</a>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('genre.destroy', $item['id'])); ?>" method="post">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                                            <button type="submit" class="btn btn-error" onlick="return false">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($data->links()); ?>

                </div>
            </div>
        </div>
    </div><!--/.row-->
</div>	<!--/.main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>