<?php $__env->startSection('content'); ?>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
    
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">My Account manager</h1>
            <?php echo $__env->make('member.component.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div><!--/.row-->
    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a class="btn btn-success" href="<?php echo route('myaccount.edit', $user['id']); ?>">Change username</a>
                    <a class="btn btn-success" href="<?php echo route('myaccount.editPassword', $user['id']); ?>">Change password</a>
                </div>
                <div class="panel-body">
                    <form class="form-horizontal">
                        <div class="form-group">
                            <label for="inputEmail3" class="col-sm-2 control-label">Username</label>
                            <div class="col-sm-10">
                            <input type="text" class="form-control" id="inputEmail3" placeholder="Username" name="txtUsername" value="<?php echo old('txtUsername', isset($user) ? $user['username'] : ''); ?>" disabled>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputPassword3" class="col-sm-2 control-label">Email address</label>
                            <div class="col-sm-10">
                            <input type="email" class="form-control" id="inputPassword3" placeholder="Email" name="txtEmail" value="<?php echo old('txtEmail', isset($user) ? $user['email'] : ''); ?>" disabled>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputPassword3" class="col-sm-2 control-label">Role</label>
                            <div class="col-sm-10">
                            <input type="text" class="form-control" id="inputPassword3" placeholder="Role" name="txtRole" value="<?php echo old('txtRole', isset($user) ? $user['role'] : ''); ?>" disabled>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div><!--/.row-->
</div>	<!--/.main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('member.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>