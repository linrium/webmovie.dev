<?php $__env->startSection('content'); ?>

<div id="random" class="main__citem animated fadeInDown">
  <div class="row main__header">
    <div class="col-md-9 col-sm-7 col-xs-5">
      <h3><?php echo e($genre['name']); ?> Anime</h3>
    </div>
  </div>

  <div class="row main__citem-content">
    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <div class="col-lg-2 col-md-3 col-sm-4 col-xs-6" >
      <div class="main__citem-item">
        <?php $lastEp = DB::table('episodes')->where('movie_id', $movie['id'])->orderBy('id', 'DESC')-> first() ?>
        <a href="<?php echo e(route('page.index', ['id'=>$movie['id'], 'episodeId'=>$lastEp->id])); ?>">
          <div class="overlay"><img src="<?php echo e(url('public/img/play.png')); ?>" /></div><img src="<?php echo e(url('public/img/'.$movie['thumb'])); ?>" alt="" class="img-responsive" />
        </a>
        <div class="main__citem-des">
          <h2><?php echo e($movie['name']); ?></h2><span># <?php echo e($movie['current_episodes']); ?>/<?php echo e($movie['total_episodes'] === 0 ? '???' : $movie['total_episodes']); ?></span>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  </div>
</div>


<script>
  window.document.title = "Webmovie - Trang xem anime online";
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>