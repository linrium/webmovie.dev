<?php $__env->startSection('content'); ?>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
    
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Episode manager</h1>
        </div>
    </div><!--/.row-->
    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">Update episode</div>
                <div class="panel-body">
                    <div class="col-lg-7">
                        <?php echo $__env->make('admin.component.alertForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <form class="form-horizontal" action="<?php echo route('episode.update', $episode['id']); ?>" method="post">
                            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                            <input type="hidden" name="_method" value="PUT">
                            <input type="hidden" name="id" value="<?php echo e($episode['id']); ?>">
                            <div class="form-group">
                                <label for="txtName" class="col-sm-3 control-label">Episode name</label>
                                <div class="col-sm-9">
                                    <input type="txt" class="form-control" id="txtName" name="txtName" value="<?php echo old('txtName', isset($episode) ? $episode['name'] : null); ?>" placeholder="Please enter episode name">
                                </div>
                            </div>
                            <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $link): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="form-group">
                                <label for="txtLink" class="col-sm-3 control-label">Episode link <?php echo e($key); ?></label>
                                <div class="col-sm-9">
                                    <input type="txt" value="<?php echo old('txtLink',$link['link']); ?>" class="form-control" id="txtLink" name="txtLink[]" placeholder="Please enter episode link">
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <div class="form-group">
                                <div class="col-sm-offset-3 col-sm-9">
                                    <button type="submit" class="btn btn-default">Update</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div><!--/.row-->
</div>	<!--/.main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>