<?php $__env->startSection('content'); ?>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
    
    <div class="row">
        <div class="col-lg-12">
            <?php $movie_name = DB::table('movies')->select('name')->where('id', $id)->get() ?>
            <h1 class="page-header">Episode of <?php echo e($movie_name[0]->name); ?></h1>
            <?php echo $__env->make('admin.component.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div><!--/.row-->
    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a class="btn btn-success" href="<?php echo route('episode.create', $id); ?>">Create Episode</a>
                    <a type="button" class="btn btn-default" href="<?php echo route('movie.index'); ?>">Close</a>
                </div>
                <div class="panel-body">
                    <table class="table table-hover">
                        <thead>
                            <th>#</th>
                            <th>Episode</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </thead>
                        <tbody>
                            <?php $stt = 0; ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <?php $stt = $stt + 1; ?>
                                <tr>
                                    <th><?php echo $stt; ?></th>
                                    <td>Episode <?php echo $item['name']; ?></td>
                                    <td>
                                        <a class="btn btn-default" href="<?php echo URL::route('episode.edit', $item['id']); ?>">Edit</a>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('episode.destroy', ['id'=>$item['id'], 'movieId' => $id])); ?>" method="post">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                                            <button type="submit" class="btn btn-error" onlick="return false">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div><!--/.row-->
</div>	<!--/.main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>