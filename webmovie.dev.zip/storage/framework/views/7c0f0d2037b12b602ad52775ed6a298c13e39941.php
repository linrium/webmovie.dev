<footer class="footer row">
        <div class="col-md-12">
          <div class="wrapper">
            <div class="row">
              <div class="col-md-3 col-sm-3 col-xs-6 footer__menu-col3">
                <ul>
                  <li><a href="">Anime</a></li>
                  <li><a href="">Thể loại</a></li>
                  <li><a href="">Năm</a></li>
                  <li><a href="">Mùa</a></li>
                  <li><a href="">Lưu trữ</a></li>
                </ul>
              </div>
              <div class="col-md-3 col-sm-3 col-xs-6 footer__menu-col3">
                <ul>
                  <li><a href="">Anime47</a></li>
                  <li><a href="">Animetvn</a></li>
                  <li><a href="">Phimmoi</a></li>
                  <li><a href="">VietDesigner</a></li>
                  <li><a href="">TechTalk</a></li>
                </ul>
              </div>
              <div class="col-md-6 col-sm-6 footer__menu-col6"><img src="<?php echo e(url('public/img/footer5.png')); ?>" alt=""/></div>
            </div>
          </div>
          <div class="row footer__coypright">
            <div class="col-md-5 col-sm-5 col-xs-12">&copy; Copyright 2016 by linh Inc.</div>
            <div class="col-md-2 col-sm-2 col-xs-12"><a href="">Term of Use</a></div>
            <div class="col-md-2 col-sm-2 col-xs-12"><a href="">Privacy Policy</a></div>
            <div class="col-md-3 col-sm-3 col-xs-12"><a href="">Design by linh Inc.</a></div>
          </div>
        </div>
      </footer>
