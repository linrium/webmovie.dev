$(document).ready(() => {

    // slide
    $('.alert').delay(3000).slideUp();

    
    //likes
    $('#likes').click(() => {
        console.log('hello');
    });
});